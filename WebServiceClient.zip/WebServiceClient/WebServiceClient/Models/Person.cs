﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebServiceClient.Models
{
    public class Person
    {
        public virtual int Id { get; set; }
        public virtual String Nome { get; set; }
        public virtual String Email { get; set; }

        public Person() { }

        public Person(int id, String nome, string email)
        {
            this.Id = id;
            this.Nome = nome;
            this.Email = email;
        }

    }
}